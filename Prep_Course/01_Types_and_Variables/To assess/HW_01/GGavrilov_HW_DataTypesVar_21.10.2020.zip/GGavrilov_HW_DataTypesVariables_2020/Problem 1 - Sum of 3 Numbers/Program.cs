﻿using System;

namespace Problem_1___Sum_of_3_Numbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            int result = a + b + c;
            Console.WriteLine(result);
        }
    }
}
