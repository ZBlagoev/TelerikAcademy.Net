﻿using System;

namespace Data_Type_and_Variables_Homework
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
