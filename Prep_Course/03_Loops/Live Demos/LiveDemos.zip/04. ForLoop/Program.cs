﻿using System;

namespace _04._ForLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int number = 1; number <= 10; number++)
            {
                Console.WriteLine($"While loop step number {number}");
            }
        }
    }
}